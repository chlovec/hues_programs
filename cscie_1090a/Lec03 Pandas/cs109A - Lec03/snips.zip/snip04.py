df['program'] = df.program.replace(r".*certificate.*", "graduate certificate [extension school]", regex=True)
df.program.value_counts()