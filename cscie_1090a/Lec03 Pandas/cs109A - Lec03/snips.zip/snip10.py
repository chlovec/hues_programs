emoji_order = pd.CategoricalDtype(categories=['🍰', '😎', '🧐', '😅', '😱', '☠️'], ordered=True)

df['hw0'] = df['hw0'].astype(emoji_order)

emoji_counts = df.groupby(['python_experience', 'hw0'], observed=False).size().unstack(fill_value=0)

emoji_proportions = emoji_counts.div(emoji_counts.sum(axis=1), axis=0)

emoji_proportions