# Here's one way to do this
str_cols = df.columns[df.dtypes == 'object']
for c in str_cols:
    df[c] = df[c].str.lower()
df.head()