dark_mode_os_crosstab = pd.crosstab(df['os'], df['dark_mode'])
dark_mode_os_crosstab