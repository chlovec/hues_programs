program_counts = df.program.value_counts()
big_programs = program_counts[program_counts >= 2].index
df[df.program.isin(big_programs)].groupby('program')['num_languages'].mean().sort_values()