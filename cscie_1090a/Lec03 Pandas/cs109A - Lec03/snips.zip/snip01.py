cols = [
    "timestamp","program","jupyter","python_exp","pandas_skill","os","dark_mode",
    "languages","continents","dob","wake_time","sleep_time","fav_season",
    "caffeine","pet","fav_movie","fav_genres","hobbies","hw0"
]