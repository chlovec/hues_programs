experience_order = pd.CategoricalDtype(categories=['Less than 1 year', '1-2 years', '2-4 years', '4+ years'], ordered=True)
df['python_experience'] = df.python_exp.astype(experience_order)
df.python_exp