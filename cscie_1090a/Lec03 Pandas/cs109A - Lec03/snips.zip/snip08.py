# Just make sure dob is a datetime (invalid -> nat)
df["dob"] = pd.to_datetime(df["dob"], errors="coerce")

# Compute age in years (floor). Result is nullable integer (Int64).
now = pd.Timestamp.now()
age_years = np.floor((now - df["dob"]).dt.days / 365.25).astype("Int64")

df.loc[:, "age"] = age_years
df.age